'''
Author: Mfan'khona Dlamini aka Bi

'''
#-----Buit--In--Functions------------
#input(), divmod(), range()
#zip(), map(), pow(), min()
#max(), sum() , isinstance(), round() 
#abs(), iter(),next(), sorted()
#int(), str(), float()
#list(), dict(), tuple(),set()
#-------------------------------------
#sets   

# =============================================================================
# prime_n = {2,3,5,7,11} 
# 
# num_n = set((0,1,2,3,4,5,5,6,7)) 
# 
# print(num_n)
# 
# #union  
# 
# union_val =  num_n | prime_n  
# union_val_two = num_n.union(prime_n)
# 
# print("union1",union_val) 
# print("union1",union_val_two)  
# 
# #intersection  
# 
# inter_val = prime_n & num_n  
# inter_val2 = prime_n.intersection(num_n)
# 
# print("intersection1: ",inter_val)
# print("intersection2: ",inter_val2) 
# 
# #difference   
# diff1 = prime_n - num_n 
# diff2 = prime_n.difference(num_n)
# 
# print("diff1: ",diff1)
# print("diff2: ",diff2)
# 
#  #remove 
#  #discard 
#  #clear 
#  #empty
#  #-----------------------
# print('---------------built-in-func----------------')
# 
# =============================================================================

domain_values =  [1,2,3,4,5,6]  

def f(x):
    return x * x 

def g(x):
    return x + 2 
  
range_values = list(map(f,domain_values))
 
range_value2 = list(map(g,domain_values))  

print(range_values) 
print(range_value2)   

print((lambda x: x * x)(3)) 

g = lambda x : x + 2  

#domain_values =  [1,2,3,4,5,6]
range_values3 = list(map(lambda x: x + 3,domain_values))

print(range_values3)  

list_user_intfo = ["Name","Age","City","Country"]

list_user1 = ["Bizzah Dlamini", 27,"Mbabane","Swaziland"]

user_intfomation = {'Name': "Alex Maseko",
                    'Age': 23,
                    'City': 'Mbabane',
                    'Country':'Eswatini'} 

user_intfo_combined = dict(zip(list_user_intfo,list_user1))

dic_function = user_intfo_combined.items() 

for k,v in dic_function:    
    print("{}:{}".format(k,v)) 
    
    
print("f(x) = x + 3")

for k,v in list(zip(domain_values,range_values3)):
    print("{} -----> {}".format(k,v))

print("f(x) = x * x")
for k, v in list(zip(domain_values,list(map(lambda x: x*x,domain_values)))):
    print("{} -----> {}".format(k,v)) 
    

print("-------------\n\n")

map_n = list(map(lambda x: x + 1,domain_values)) 

print("Map_n: ",map_n) 

for_loop_map = [x*x for x in list(range(1,7))]  

print("for_loop_map: ",for_loop_map) 


list_n = [x for x in range(1,11)] 
 
print("list_n: ",list_n)

print("Min:",min(list_n))
print("Max:",max(list_n))
print("Sum:",sum(list_n))  

print("---------------------\n\n\n")
a = 12 
b = '13'  

if isinstance(a, int) and isinstance(b, int):
    print(sum([a,b]))
else: 
    print("check your values if they are integers")


g = 13 
h = 2 
true_value = g / h  

print("{}  / {} = {}".format(g,h,true_value)) 

cut_div = g // h
  
print("{}  // {} = {}".format(g,h,cut_div))  

d,m = divmod(13, 2)  
print("div:{}, mod: {}".format(d,m)) 
 
print(13 % 2)  

import math 

print(math.sqrt(abs(-4))) 

list_new_val = [1,2,3,4,5]  

it = iter(list_new_val) 
print("----------------------------")

print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))
print(next(it))

#input 
#sorted
#filter 






































