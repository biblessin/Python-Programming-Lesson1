import comparisonop as op 
import operator as p

#-----comparison operators:
# >       greater than 
# <       less than 
# >=      greater or equal to 
# <=      less than or equal to 

#------equality operators 
# == equal 
# != not equal 

#----logical operators: 
# and 
# or 
# not  


a = 2 
b = 4 
c = 1 
f = 4 
print("{} > {} : {}".format(a,b, a>b))
print("{} < {} : {}".format(a,b, a<b))
print("{} == {} : {}".format(b,f, b == f))
print("{} != {} : {}".format(b,f, b != f))
print("{} >= {} : {}".format(a,b, a >= b))
print("{} <= {} : {}".format(a, b ,a<=b))

# if a > b : 
#     print( "a is greater than b")
# else: 
#     print( "a is not greater than b") 


# if b > f:
#     print('b is greater than f')
# elif b == f:
#     print("b  is equal to f")
# else: 
#     print('b is less than f') 


x = 4 
y = 7 

if p.lt(x,y):
    print("sum:", x + y) 
else: 
    print("sub:", x - y)

    
age = 12 

if age> 10  or age <18:
    print("Dont drink alcohol")
else: 
    print("Drink alcohol")













