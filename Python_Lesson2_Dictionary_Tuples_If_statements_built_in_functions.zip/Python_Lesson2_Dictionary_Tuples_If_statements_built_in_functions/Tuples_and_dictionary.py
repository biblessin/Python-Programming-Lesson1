'''
Tuple is a list that is immutable
- this means that one can not add items into a tuple
- just like list tuples can be unpacked into variables

'''

"""
The following co-ordinates will be used to calcuate gradient
"""
# ====Coordinates====
# A(1,2) B(5,6) 
#==formular for calculating Gradient
# m = (y2-y1) / (x2-x1)

#====expected outcome====
# A(x1,y1) B(x2,y2) 
# m = (6-2) / (5-1)  => 4 /4 => 1
#==========================
# #A(1,2)
# x1 = 1 
# y1 = 2 

# #B(5,6)
# x2 = 5 
# y2 = 6  

#A(1,2) 

#=====list=====
list_val = []

list_val.append(2)
list_val.append(24)
list_val.append(72)


# num_tuple = (1,2,3,4,5,6)
# print(type(num_tuple)) 

# num_tuple2 = tuple((1,2,3,4,5,6))
# print(type(num_tuple2))

# num_tuple3 = 12,34,55,66,77 
# print(type(num_tuple3)) 

#=====tuples======
#A(12,2) 

A = (12,2) 
x1,y1 = A


#B(6,6)
# m = (y2-y1) / (x2-x1) 
# m = (6-2) / (6-12) = 4 / (-6) - 2/3


B = (6,6) 
x2,y2 = B


def gradient(x1,y1,x2,y2):
    '''
    function for calculating gradient
    '''
    return (y2-y1) / (x2-x1)

m = gradient(x1,y1,x2,y2)

print("Gradient = ",m) 

prime_tuple = (2,3,5,7,11)  

prime_list = list(prime_tuple) 
prime_list.append(13)
print(prime_list)
changed_tuple = tuple(prime_list) 

print("Changed tuple:", changed_tuple)

print(changed_tuple[0])
print(changed_tuple[-1])
print(changed_tuple[:4]) 

print(len(changed_tuple))








