
"""
A dictionary is a list of key value pairs
- the key needs to be immutable data type. e.g string and int

"""
# student dictionary 
student_info = {
    '''
    keys[strings]: name, age,class
    
    '''
    'name': 'Bizzah Dlamini', 
    'age': 27,
    'class': 'Grade 12'
    } 

# print(student_info)
# print(type(student_info))

# print(student_info.keys())
# print(student_info.values()) 
# print(student_info.items()) 

# user = student_info.copy()
# # print("user:",user) 
# print(user.get('name'))
# print(user['age'])
# user['country'] = 'Kingdom of Eswatini'  
# print(user)

# print('----------------------------------------')

"""
One can use the for in loops to loop iterate 
through a dictionary
"""
# for k, v in user.items():
#     print('{} : {}'.format(k,v))


"""
- Calculating Gradient
- values will be taken from a dictionary
"""
# A(4,2) B(6,6) 
# m = (y2-y1)/ (x2-x1) 
# m = (6-2) /(6-4) => 4/2 = 2


def gradient(x1,y1,x2,y2):
    '''
    Function for calculating a gradient
    '''
    return (y2-y1) / (x2-x1) 


'''
Two dictionaries that holds key value pairs
of the two points

'''
A = {'x': 4, 'y': 2}
B = {'x':6, 'y':6} 

'''
Passing the key value pairs of the two dictionary
into the gradient function

'''
m = gradient(A['x'],A['y'],B['x'],B['y'])

print('m = {}'.format(int(m)))







