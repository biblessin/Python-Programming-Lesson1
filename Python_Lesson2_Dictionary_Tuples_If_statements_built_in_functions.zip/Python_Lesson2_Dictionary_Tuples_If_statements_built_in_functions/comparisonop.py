

def less_than(x,y):
    return x < y  
def greater_than(x,y):
    return x > y 
def equal_to(x,y):
    return x == y 

def not_equal_to(x,y):
    return x != y  
def less_than_or_equal_to(x,y):
    return x <= y






