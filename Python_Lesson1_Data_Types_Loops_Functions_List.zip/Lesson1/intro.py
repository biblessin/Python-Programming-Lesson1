

"""
Author: Mfan'khona Dlamini

"""
# given : a = 23 , b = 2, c = 4

# a + b

"""
- Everything in python is an object
- 'a,b,c' below are variables.
- variables are storage containers that hold objects in python

===The following objects are called Data types:
->integer {negetive or positive numbers without decimals}
-> float => {numbers with decimals}
-> bolean => {True / False}
-> string => {an array of characters.}
-> list  => { a collection of object} #list are mutable
-> tuples => {immutable list} 
-> dictioneries => {a collection of key value pairs}
-> sets => {a collection objects which are non-repeating}

"""
a = 23  # variable 'a' hold value '23'
b = 2 #variable 'b' hold value '2'
c = 4 #variable 'c' hold value '4'

sum = a + b #variable 'sum' hold value '23 + 2'

#print method for print out objects
print(" {} +  {}  = {}".format(a,b,sum))


"""
Python can turn into a calculator an perfom all basic operations:
- addition
-subtraction
- division
-multiplication
-modulus

"""

#multiplication
product = a * b

print("{} * {} = {} ".format(a,b,product))

#division
div_val =  a / b

print(" {} / {} = {}".format(a,b,div_val))

#remainder
mod_val = a % b


print(" {} % {} = {} ".format(a,b,mod_val))

# subtraction
diff_val = c - b

print("{} - {} = {}".format(c,b,diff_val)) 


#========Data Type Operations========
#integer

print(1 + 2)

#float 
print(3 / 2)

#string

user_name = "Bizzah  Dlamini"

print(user_name)

#boolean

done = True
not_done = False

#Next lesson list















