
'''
There are 2 types of loops in python:
-> while loop
-> for in loop
'''



#while loop in action

i = 1 # initialiser for the loop
n = 4 # value that will make the loop if it is true

while i < n: # the loop will run if this block is true
     print(i)
     i = i + 1 # this prevent infinite loop




print("---------for----------------")
#for loop loop in action

n = 5 #range value
for j in range(1,n+1):
    print(j) #printing out values from 1 to 5


#list with loops
num = [] # empty list 
print("Before:",num)
n = 6
for j in range(1,n+1):
    num.append(j) # values from 1 to 6 inserted into list storage

print("After:",num) # print out new now-epmty list

#Next lesspn: functions 
