

#List of integers
# 1 2 3 4 5 6

number = [1,2,3,4,5,6]

print(number)
#add objects into a list
number.append(7)
number.append(8)

print(number)

#remove object into a list
number.pop()

print("pop:",number) #print new list after pop()

#new list
num_two = [9,10,11,12]

#add a list object into another list
number.extend(num_two)

print(number) #print list

#new list
num_three = [13,14,15]

#combine two list
combine_numbers = number  + num_three

print(combine_numbers) #print list

# Next lesson: Loops



