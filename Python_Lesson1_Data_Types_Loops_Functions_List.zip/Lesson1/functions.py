

'''
- One way of organizing objects together is through function
- functions enable related objects to be grouped together thus
make it easy to be manage
- it also aid in data hiding

'''
#print(): function-built-In
print("Hello world")


#--custom functions-----
#f(x)  =  x + 2
# f(2) = 2 + 2 => 4 

#sum function
def f(x):
    return x + 2

#print(f(2))
#print(f(3))

#add function
def add(a,b):
    '''
    Arg:a, b 
    return: sum of 'a' and 'b'
    '''
    return a + b

a = 4
b = 5

# function return values stored into sum_a_b
sum_a_b = add(a,b)
#print out the add function op
print("{} + {} = {}".format(a,b,sum_a_b))
print("{} + {} = {}".format(2,4,add(2,4)))
print("{} + {} = {}".format(3,7,add(3,7)))


#multiplication function
def mult(a,b):
    '''
    arg: a, b
    return: product of 'a' and 'b'
    
    '''
    return a  * b

def div(a,b):
    '''
    arg: a, b
    return quotient of 'a' and 'b'
    '''
    return a / b

def mod_val(a,b):
    '''
    arg: a,b
    return: modulus of 'a' and 'b'
    '''
    return a % b


def sub(a,b):
    '''
    arg: a, b
    return: difference of 'a' and 'b'
    '''
    return a - b





